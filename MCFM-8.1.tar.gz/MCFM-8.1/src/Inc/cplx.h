C---Begin statement function
      complex(dp):: cplx1,cplx2
      real(kind=dp):: xxxx,yyyy
      cplx1(xxxx)=cmplx(xxxx,0._dp,kind=dp)
      cplx2(xxxx,yyyy)=cmplx(xxxx,yyyy,kind=dp)
C---end statement function
